<?php
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['email'])) {
    // Se não estiver logado, redirecione para a página de login
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!---link css--->
    <link rel="stylesheet" href="css/estilo5.css">

    <!---link boxicons--->
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">

    <!---link remixicons--->
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.2.0/fonts/remixicon.css" rel="stylesheet">

    <!---link google fonts--->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Crete+Round&display=swap" rel="stylesheet">

    <title>Document</title>
</head>

<body>
<div id="overlay"></div>
    <header>
        <a href="#" class="logo"></a>

        <ul class="navlist">
            <li><a href="home.php">Home</a></li>
            <li><a href="sobre.php">Sobre</a></li>
            <li><a href="servicos.php">Serviços</a></li>
            <li><a href="#" class="ctaa" onclick="openPerfil()">Perfil</a></li>
            <li><a href="logout.php">Sair</a></li>
            
        </ul>

        <div class="bx bx-menu" id="menu-icon">

        </div>
    </header>

    <section class="logotipo">
        <div class="logotipo-text">
            <h5></h5>
            <h4>Barbearia</h4>
            <h1>MEN'S CLUB</h1>
            <a href="#">Tornar-se Cliente!</a>
            <a href="#" class="ctaa" onclick="openCalendario()"><i class="ri-play-fill">Agendar ja!</i></a>
        </div>

        <div class="logotipo-img">
            <img src="imgs/vetorbarber.svg">

        </div>
    </section>

    <div class="icons">
        <a href="#"><i class="ri-instagram-line"></i></a>
        <a href="#"><i class="ri-whatsapp-line"></i></a>
        <a href="https://www.facebook.com/MensClubBarberShoop"><i class="ri-facebook-line"></i></a>
    </div>

    <div class="scroll-down">
        <a href="#"><i class="ri-arrow-down-s-fill"></i></a>
    </div>

    <!---scrollreveal effect--->
    <script src="https://unpkg.com/scrollreveal"></script>

    <!---link js--->
    <script src="js/script2.js"></script>
    
    <script>
         function openCalendario() {
            document.getElementById('overlay').style.display = 'block';
    const calendarioContainer = document.querySelector('.container');

    const telaAgendamento = document.createElement('div');
    telaAgendamento.classList.add('tela-agendamento');
    document.body.appendChild(telaAgendamento);

    const iframe = document.createElement('iframe');
    iframe.src = 'calendario.php'; // Alterado para o arquivo calendario.php
    iframe.frameBorder = 0;
    iframe.allowFullscreen = true;
    iframe.classList.add('iframe-agendamento');
    document.body.appendChild(iframe);

    const closeButton = document.createElement('button');
    closeButton.textContent = 'Fechar';
    closeButton.classList.add('close-button');
    document.body.appendChild(closeButton);

    closeButton.addEventListener('click', function() {
        document.body.removeChild(telaAgendamento);
        document.body.removeChild(iframe);
        document.body.removeChild(closeButton);
    });
}

function openPerfil() {
    document.getElementById('overlay').style.display = 'block';
    const calendarioContainer = document.querySelector('.container');

    const telaAgendamento = document.createElement('div');
    telaAgendamento.classList.add('tela-agendamento');
    document.body.appendChild(telaAgendamento);

    const iframe = document.createElement('iframe');
    iframe.src = 'perfil.php'; // Alterado para o arquivo Perfil.php
    iframe.frameBorder = 0;
    iframe.allowFullscreen = true;
    iframe.classList.add('iframe-agendamento');
    document.body.appendChild(iframe);

    const closeButton = document.createElement('button');
    closeButton.textContent = 'Fechar';
    closeButton.classList.add('close-button');
    document.body.appendChild(closeButton);

    closeButton.addEventListener('click', function() {
        document.body.removeChild(telaAgendamento);
        document.body.removeChild(iframe);
        document.body.removeChild(closeButton);
    });
}
    </script>
</body>

</html>