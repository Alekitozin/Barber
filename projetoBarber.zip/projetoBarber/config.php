<?php

define('host', 'localhost');
define('user', 'root');
define('seinha', '');
define('base', 'MensClub');

$conn = new mysqli(host, user, seinha, base);

// Verifica a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

?>
