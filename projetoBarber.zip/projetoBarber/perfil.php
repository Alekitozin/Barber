<?php
include "config.php";
session_start();

if (!isset($_SESSION['email'])) {
    header('Location: login.php');
    exit;
}

$email_usuario = $_SESSION['email'];

$sql = "SELECT id_cliente, nome_usuario, email, telefone, foto_perfil FROM clientes WHERE email = '$email_usuario'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $id_usuario = $row["id_cliente"];
        $nome_usuario = $row["nome_usuario"];
        $email = $row["email"];
        $telefone = $row["telefone"];
        $foto_perfil = $row["foto_perfil"];
    }
} else {
    echo "0 results";
}

$conn->close();


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil</title>
    <link rel="stylesheet" type="text/css" href="css/perfil.css">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.2.0/fonts/remixicon.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Crete+Round&display=swap" rel="stylesheet">
    <style>
        /* Estilos existentes */
        .container {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .profile {
            color: black;
        }

        .profile p {
            margin: 5px 0;
        }

        .profile-image img {
            border-radius: 50%;
            width: 150px;
            height: 150px;
            object-fit: cover;
        }

        .camera-icon {
            opacity: 0;
        }

        .button {
            display: inline-block;
            padding: 10px 20px;
            background-color: rgb(30, 30, 30); /* Cor de fundo do botão */
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 300px;
            margin-top: 10px;
            margin-left: 5px;
            margin-right: 5px;
            width: 150px; /* Adicionando largura fixa aos botões */
        }

        .button:hover {
            background-color: rgb(20, 20, 20); /* Cor de fundo do botão ao passar o mouse */
        }

        /* Estilos específicos para o botão de Enviar */
        .enviar-button {
            background-color: rgb(30, 30, 30); /* Cor de fundo do botão Enviar */
        }

        .enviar-button:hover {
            background-color: rgb(20, 20, 20); /* Cor de fundo do botão Enviar ao passar o mouse */
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Perfil</h1>
        <div class="profile">
            <form action="atualizar_foto.php" method="POST" enctype="multipart/form-data">
                <div class="profile-image" onmouseover="showCameraIcon()" onmouseout="hideCameraIcon()">
                    <img src="<?php echo $foto_perfil; ?>" alt="Foto de Perfil" id="profileImage">
                    <i class="fas fa-camera camera-icon" id="cameraIcon"></i>
                </div>
                <div style="display: flex; justify-content: center;">
                    <input type="file" name="novaFoto" id="novaFoto" accept="image/*" style="display: none;">
                    <button type="button" class="button" onclick="openFileSelector()">Selecionar Foto</button>
                    <input type="submit" name="enviarFoto" value="Enviar" class="button enviar-button">
                </div>
            </form>
            <hr>
            <div class="input-box">
                <span class="icon"><i class='bx bxs-user'></i></span>
                <input type="text" value="<?php echo $nome_usuario; ?>" readonly>
                <label>Nome</label>
            </div>
            <div class="input-box">
                <span class="icon"><i class='bx bxs-envelope'></i></span>
                <input type="email" value="<?php echo $email; ?>" readonly>
                <label>Email</label>
            </div>
            <div class="input-box">
                <span class="icon"><i class='bx bxs-phone'></i></span>
                <input type="tel" value="<?php echo $telefone; ?>" readonly>
                <label>Telefone</label>
            </div>
            <div class="input-box">
                <span class="icon"><i class='bx bx-cut'></i></span>
                <input type="text" readonly>
                <label>Agendamentos Concluídos</label>
            </div>
        </div>
    </div>

    <script>
        function showCameraIcon() {
            document.getElementById("cameraIcon").style.opacity = "1";
        }

        function hideCameraIcon() {
            document.getElementById("cameraIcon").style.opacity = "0";
        }

        function openFileSelector() {
            document.getElementById("novaFoto").click();
        }

        document.getElementById('novaFoto').addEventListener('change', function () {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function (e) {
                    document.getElementById('profileImage').src = e.target.result;
                };
                reader.readAsDataURL(file);
            }s
        });
    </script>
</body>

</html>
