<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>

    <!--link css-->
    <link rel="stylesheet" type="text/css" href="css/login1.css">

    <!---link boxicons--->
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">

    <!---link remixicons--->
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.2.0/fonts/remixicon.css" rel="stylesheet">

    <!--link google fonts-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Crete+Round&display=swap" rel="stylesheet">
    <style>
    
        .main-box {
            transition: transform 1s;
            transform-style: preserve-3d;
            position: relative;
            width: 400px;
            height: 500px;
        }
        .flip {
            transform: rotateY(180deg);
        }
        .front, .back {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            backface-visibility: hidden;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        .back {
            transform: rotateY(180deg);
        }
    </style>
</head>
<body>
   <div class="container">
        <div class="main-box" id="main-box">
            <div class="front">
                <h1>Log In</h1>
                <form action="processa_login.php" method="POST">
                    <div class="input-box">
                        <span class="icon"><i class='bx bxs-envelope'></i></span>
                        <input type="email" name="email" id="email" required>
                        <label>Email</label>
                    </div>

                    <div class="input-box">
                        <span class="icon"><i class='bx bxs-lock-alt'></i></span>
                        <input type="password" name="senha" id="senha" required>
                        <label>Senha</label>
                    </div>
                        
                    <div class="check">
                        <label><input type="checkbox">Lembre-me</label>
                            <a href="#" class="forgot-password">Esqueci a senha</a>
                    </div>

                    <button type="submit" class="btn">Login</button>

                    <div class="register">
                        <p>Não tem uma conta?<a href="#" class="register-link" id="register-link" onclick="handleFlip(event)">Cadastre-se!</a></p>
                    </div>
                </form>
            </div>
            <div class="back">
                <h1>Cadastro</h1>
                <form action="processa_cadastro.php" method="POST">
                    <input type="hidden" name="acao" value="cadastrar">

                    <div class="input-box">
                        <span class="icon"><i class='bx bxs-user'></i></span>
                        <input type="text" name="nome_usuario" required>
                        <label>Nome de usuário</label>
                    </div>

                    <div class="input-box">
                        <span class="icon"><i class='bx bxs-phone'></i></span>
                        <input type="tel" name="telefone" required>
                        <label>Telefone</label>
                    </div>

                    <div class="input-box">
                        <span class="icon"><i class='bx bxs-envelope'></i></span>
                        <input type="email" name="email" required>
                        <label>Email</label>
                    </div>

                    <div class="input-box">
                        <span class="icon"><i class='bx bxs-lock-alt'></i></span>
                        <input type="password" name="senha" required>
                        <label>Senha</label>
                    </div>

                    <div class="check">
                        <label><input type="checkbox">Lembre-me</label>
                        <a href="#">Esqueci a senha</a>
                    </div>

                    <button type="submit" class="btn">Cadastrar-se</button>

                    <div class="register">
                        <p>Já tem uma conta?<a href="#" class="register-link" id="login-link" onclick="handleBackFlip(event)">Log in!</a></p>
                    </div>
                </form>
            </div>
        </div>
   </div>

   <script>

    
    
       function handleFlip(event) {
           event.preventDefault();
           const mainBox = document.getElementById('main-box');
           mainBox.classList.toggle('flip');
       }

       function handleBackFlip(event) {
       event.preventDefault();
       const mainBox = document.getElementById('main-box');
       mainBox.classList.toggle('flip');
   }

       const inputElement = document.querySelector('input[name="telefone"]');
        inputElement.addEventListener('input', (event) => {
            let phoneNumber = event.target.value;
            phoneNumber = phoneNumber.replace(/\D/g, '');
            if (phoneNumber.length > 0) {
                phoneNumber = '(' + phoneNumber;
            }
            if (phoneNumber.length > 3) {
                phoneNumber = [phoneNumber.slice(0, 3), ')', phoneNumber.slice(3)].join('');
            }
            if (phoneNumber.length > 9) {
                phoneNumber = [phoneNumber.slice(0, 9), '-', phoneNumber.slice(9)].join('');
            }
            if (phoneNumber.length > 14) {
                phoneNumber = phoneNumber.slice(0, 14);
            }
            inputElement.value = phoneNumber;
        });

   </script>
   

   
</body>
</html>
