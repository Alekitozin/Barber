
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!---link css--->
    <link rel="stylesheet" href="css/estilo5.css">

    <!---link boxicons--->
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">

    <!---link remixicons--->
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.2.0/fonts/remixicon.css" rel="stylesheet">

    <!---link google fonts--->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Crete+Round&display=swap" rel="stylesheet">


    
    <title>Document</title>
</head>

<body>
    <header>
        <a href="#" class="logo"></a>

        <ul class="navlist">
            <li><a href="#" class="ctaa" onclick="openLogin()">Home</a></li>
            <li><a href="sobre.php">Sobre</a></li>
            <li><a href="servicos.php">Serviços</a></li>
            <li><a href="#" class="ctaa" onclick="openLogin()">Perfil</a></li>
        </ul>

        <div class="bx bx-menu" id="menu-icon">

        </div>
    </header>

    <section class="logotipo">
        <div class="logotipo-text">
            <h5></h5>
            <h4>Barbearia</h4>
            <h1>MEN'S CLUB</h1>
            <a href="#">Sei la</a>
            <a href="#" class="ctaa" onclick="openLogin()"><i class="ri-play-fill">Agendar ja!</i></a>
        </div>

        <div class="logotipo-img">
            <img src="imgs/vetorbarber.svg">

        </div>
    </section>

    <div class="icons">
        <a href="#"><i class="ri-instagram-line"></i></a>
        <a href="#"><i class="ri-whatsapp-line"></i></a>
        <a href="https://www.facebook.com/MensClubBarberShoop"><i class="ri-facebook-line"></i></a>
    </div>

    <div class="scroll-down">
        <a href="#"><i class="ri-arrow-down-s-fill"></i></a>
    </div>

    <!---scrollreveal effect--->
    <script src="https://unpkg.com/scrollreveal"></script>

    <!---link js--->
    <script src="js/index.js"></script>

    <script>
    let loginOpened = false;

    function openLogin() {
        if (loginOpened) {
            return;
        }

        loginOpened = true;

        const telaOpaca = document.createElement('div');
        telaOpaca.classList.add('tela-opaca');
        document.body.appendChild(telaOpaca);

        const telaAgendamento = document.createElement('div');
        telaAgendamento.classList.add('tela-agendamento');
        document.body.appendChild(telaAgendamento);

        // Adicione a classe "mostrar" com um pequeno atraso para a animação ser perceptível
        setTimeout(() => {
            telaAgendamento.classList.add('mostrar');
        }, 100);

        const iframe = document.createElement('iframe');
        iframe.src = 'login.php';
        iframe.frameBorder = 0;
        iframe.allowFullscreen = true;
        iframe.classList.add('iframe-agendamento');
        document.body.appendChild(iframe);

        const closeButton = document.createElement('button');
        closeButton.textContent = 'Fechar';
        closeButton.classList.add('close-button');
        document.body.appendChild(closeButton);

        closeButton.addEventListener('click', function() {
            document.body.removeChild(telaOpaca);
            document.body.removeChild(telaAgendamento);
            document.body.removeChild(iframe);
            document.body.removeChild(closeButton);

            loginOpened = false;
        });

        const errorParagraph = document.createElement('p');
        errorParagraph.classList.add('error-message');
        telaAgendamento.appendChild(errorParagraph);

        // Adiciona um ouvinte de mensagem de erro do iframe
        window.addEventListener('message', function(event) {
            if (event.data.error) {
                errorParagraph.textContent = event.data.error; // Exibe a mensagem de erro recebida do iframe
            }
        });
    }
</script>
</body>

</html>


