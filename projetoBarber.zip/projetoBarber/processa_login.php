<?php
session_start();
include "config.php";

if(isset($_POST["email"]) && isset($_POST["senha"])) {
    $email = $_POST["email"];
    $senha = $_POST["senha"];

    $sql = "SELECT * FROM clientes WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();

    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if($user) {
        if(password_verify($senha, $user["senha"])) {
            $_SESSION["email"] = $user["email"];
            echo "<script>window.top.location='home.php'</script>"; // Redirecionamento para home.php após o login bem-sucedido
            exit(); // Certifique-se de sair do script após o redirecionamento
        } else {
            echo "<script>window.parent.postMessage({ error: 'Email ou Senha incorretos' }, '*');</script>"; // Envie a mensagem de erro para a janela pai
            exit();
        }
    } else {
        echo "<script>window.parent.postMessage({ error: 'Email ou Senha incorretos' }, '*');</script>"; // Envie a mensagem de erro para a janela pai
        exit();
    }
} else {
    echo "Email ou Senha incorretos";
}
?>