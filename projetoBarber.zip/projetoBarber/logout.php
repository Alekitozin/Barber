<?php
session_start();

// Destrua a sessão
session_destroy();

// Redirecione para a página de login ou qualquer outra página desejada
header('Location: index.php');
exit;
?>