<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/sobre.css">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.2.0/fonts/remixicon.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Crete+Round&display=swap" rel="stylesheet">
    <title>Document</title>
</head>

<body>
    <div id="overlay"></div>
    <header>
        <a href="#" class="logo"></a>
        <ul class="navlist">
            <li><a href="#" onclick="openLogin()">Home</a></li>
            <li><a href="#">Sobre</a></li>
            <li><a href="servicos.php">Serviços</a></li>
            <li><a href="#" class="ctaa" onclick="<?php if (!isset($_SESSION['email'])) { ?> openLogin() <?php } else { ?> openPerfil() <?php } ?>">Perfil</a></li>
            <?php if (isset($_SESSION['email'])) { ?>
                <li><a href="logout.php">Sair</a></li>
            <?php } ?>
        </ul>
        <div class="bx bx-menu" id="menu-icon"></div>
    </header>

    <section class="logotipo">
        <div class="logotipo-text">
            <h4>Barbearia Men's Club</h4>
            <h1>Quem somos?</h1>
            <h4>Bem-vindo à nossa barbearia localizada no coração da encantadora cidade de São Pedro do Turvo. Nossa equipe apaixonada e experiente se dedica a oferecer uma experiência excepcional de cuidados masculinos. Combinamos cortes de cabelo e barba de alta qualidade com um atendimento personalizado e um ambiente acolhedor. Além dos serviços de corte de cabelo clássicos e modernos, oferecemos cuidados especializados para barbas bem cuidadas, tratamentos de cuidados masculinos e realce de sobrancelhas. Na nossa barbearia, celebramos a tradição enquanto abraçamos a inovação, garantindo que cada cliente saia com um visual elegante e uma confiança renovada.</h4>
            <a href="#">Sei la</a>
            <a href="#" class="ctaa" onclick="<?php if (!isset($_SESSION['email'])) { ?> openLogin() <?php } else { ?> openCalendario() <?php } ?>"><i class="ri-play-fill">Agendar ja!</i></a>
        </div>

        <div class="logotipo-img">
            <img src="imgs/vetorbarber.svg">
        </div>
    </section>

    <div class="icons">
        <a href="#"><i class="ri-instagram-line"></i></a>
        <a href="#"><i class="ri-whatsapp-line"></i></a>
        <a href="https://www.facebook.com/MensClubBarberShoop"><i class="ri-facebook-line"></i></a>
    </div>

    <div class="scroll-down">
        <a href="#"><i class="ri-arrow-down-s-fill"></i></a>
    </div>

    <script src="https://unpkg.com/scrollreveal"></script>
    <script src="js/script2.js"></script>

    <script>
        let loginOpened = false;

        function openLogin() {
            if (loginOpened) {
                return;
            }

            loginOpened = true;

            const telaOpaca = document.createElement('div');
            telaOpaca.classList.add('tela-opaca');
            document.body.appendChild(telaOpaca);

            const telaAgendamento = document.createElement('div');
            telaAgendamento.classList.add('tela-agendamento');
            document.body.appendChild(telaAgendamento);

            // Adicione a classe "mostrar" com um pequeno atraso para a animação ser perceptível
            setTimeout(() => {
                telaAgendamento.classList.add('mostrar');
            }, 100);

            const iframe = document.createElement('iframe');
            iframe.src = 'login.php';
            iframe.frameBorder = 0;
            iframe.allowFullscreen = true;
            iframe.classList.add('iframe-agendamento');
            document.body.appendChild(iframe);

            const closeButton = document.createElement('button');
            closeButton.textContent = 'Fechar';
            closeButton.classList.add('close-button');
            document.body.appendChild(closeButton);

            closeButton.addEventListener('click', function() {
                document.body.removeChild(telaOpaca);
                document.body.removeChild(telaAgendamento);
                document.body.removeChild(iframe);
                document.body.removeChild(closeButton);

                loginOpened = false;
            });

            const errorParagraph = document.createElement('p');
            errorParagraph.classList.add('error-message');
            telaAgendamento.appendChild(errorParagraph);

            // Adiciona um ouvinte de mensagem de erro do iframe
            window.addEventListener('message', function(event) {
                if (event.data.error) {
                    errorParagraph.textContent = event.data.error; // Exibe a mensagem de erro recebida do iframe
                }
            });
        }

        function openCalendario() {
            <?php if (!isset($_SESSION['email'])) { ?>
                window.location.href = 'login.php';
            <?php } else { ?>
                document.getElementById('overlay').style.display = 'block';
                const calendarioContainer = document.querySelector('.container');
                const telaAgendamento = document.createElement('div');
                telaAgendamento.classList.add('tela-agendamento');
                document.body.appendChild(telaAgendamento);
                const iframe = document.createElement('iframe');
                iframe.src = 'calendario.php'; // Alterado para o arquivo calendario.php
                iframe.frameBorder = 0;
                iframe.allowFullscreen = true;
                iframe.classList.add('iframe-agendamento');
                document.body.appendChild(iframe);
                const closeButton = document.createElement('button');
                closeButton.textContent = 'Fechar';
                closeButton.classList.add('close-button');
                document.body.appendChild(closeButton);
                closeButton.addEventListener('click', function() {
                    document.body.removeChild(telaAgendamento);
                    document.body.removeChild(iframe);
                    document.body.removeChild(closeButton);
                });
            <?php } ?>
        }

        function openPerfil() {
            document.getElementById('overlay').style.display = 'block';
            <?php if (!isset($_SESSION['email'])) { ?>
                window.location.href = 'login.php';
            <?php } else { ?>
                const calendarioContainer = document.querySelector('.container');
                const telaAgendamento = document.createElement('div');
                telaAgendamento.classList.add('tela-agendamento');
                document.body.appendChild(telaAgendamento);
                const iframe = document.createElement('iframe');
                iframe.src = 'perfil.php'; // Alterado para o arquivo Perfil.php
                iframe.frameBorder = 0;
                iframe.allowFullscreen = true;
                iframe.classList.add('iframe-agendamento');
                document.body.appendChild(iframe);
                const closeButton = document.createElement('button');
                closeButton.textContent = 'Fechar';
                closeButton.classList.add('close-button');
                document.body.appendChild(closeButton);
                closeButton.addEventListener('click', function() {
                    document.body.removeChild(telaAgendamento);
                    document.body.removeChild(iframe);
                    document.body.removeChild(closeButton);
                });
            <?php } ?>
        }
    </script>
</body>

</html>
