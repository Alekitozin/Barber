<?php

include "config.php";

switch ($_POST["acao"])
{
    case 'cadastrar':
        $nome_usuario = $_POST["nome_usuario"];
        $email = $_POST["email"];
        $senha = $_POST["senha"];
        $telefone = $_POST["telefone"];

        // Criptografa a senha
        $senha_criptografada = password_hash($senha, PASSWORD_DEFAULT);

        $sql = "INSERT INTO clientes (nome_usuario, email, senha, telefone) VALUES (?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
        if ($stmt)
        {
            $stmt->bind_param("ssss", $nome_usuario, $email, $senha_criptografada, $telefone);

            $exec = $stmt->execute();

            if ($exec)
            {
                echo "<script> alert('Usuário cadastrado com sucesso!!!') </script>";
                echo "<script> location.href='login.php'</script>";
            }
            
            else
            {
                echo "<script> alert('Não foi possível cadastrar o usuário!!!') </script>";
            }

            $stmt->close();

        }

        else
        {
            echo "erro" . $conn->error;
        } 

        $conn->close();
        break;
}       

?>
