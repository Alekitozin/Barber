<?php
include "config.php";
session_start();

if (!isset($_SESSION['email'])) {
    header('Location: login.php');
    exit;
}

$email_usuario = $_SESSION['email'];

// Verifica se um arquivo foi enviado
if (isset($_FILES['novaFoto']) && $_FILES['novaFoto']['error'] === UPLOAD_ERR_OK) {
    // Pasta onde as imagens serão armazenadas
    $pasta_destino = 'uploads/';

   // Verifica se a pasta de destino existe e é gravável
if (!is_dir($pasta_destino)) {
    // Tente criar a pasta se ela não existir
    if (!mkdir($pasta_destino) && !is_dir($pasta_destino)) {
        echo "Erro: Não foi possível criar a pasta de destino.";
        exit;
    }
} elseif (!is_writable($pasta_destino)) {
    echo "Erro: A pasta de destino não é gravável.";
    exit;
}

    // Gera um nome de arquivo único com base no tempo e um prefixo (por exemplo, o ID do usuário)
    $nome_arquivo = $email_usuario . '_' . time() . '_' . basename($_FILES['novaFoto']['name']);
    
    // Caminho completo para o arquivo
    $caminho_arquivo = $pasta_destino . $nome_arquivo;
    
    // Move o arquivo para a pasta de destino
    if (move_uploaded_file($_FILES['novaFoto']['tmp_name'], $caminho_arquivo)) {
        // Atualiza a coluna de foto_perfil no banco de dados
        $sql = "UPDATE clientes SET foto_perfil = ? WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ss', $caminho_arquivo, $email_usuario);
        
        if ($stmt->execute()) {
            // Redireciona para a página de perfil com uma mensagem de sucesso
            header('Location: perfil.php?success=1');
            exit;
        } else {
            // Em caso de erro no banco de dados, exibe a mensagem de erro
            echo "Erro ao atualizar a foto no banco de dados: " . $stmt->error;
        }
    } else {
        // Em caso de erro ao mover o arquivo, exibe a mensagem de erro
        echo "Erro ao mover o arquivo para a pasta de destino.";
    }
} else {
    // Se nenhum arquivo foi enviado ou ocorreu um erro no upload, exibe a mensagem apropriada
    echo "Nenhum arquivo foi enviado ou ocorreu um erro no upload.";
}
?>
