<?php
    session_start();
    $loggedIn = isset($_SESSION['email']);
    echo json_encode(array('loggedIn' => $loggedIn));
?>

<!DOCTYPE html>
<html>

<head>

<meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
        body {
            position: relative;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: black;
        }

        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url(imgs/vetorbarber.svg) no-repeat center center;
            background-size: 45.5%;
            filter: blur(5px);
        }

        h1 {
            text-align: center;
            color: white;
            margin: 20px auto 0;
            position: absolute;
            top: 0;
            left: 50%;
            transform: translateX(-50%);
            padding: 10px 20px;
            font-size: 42px;
            font-family: 'Roboto Slab', serif;
        }

        .gallery {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            justify-content: center;
            padding: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .gallery-item {
            flex: 0 0 calc(20% - 20px);
            position: relative;
            overflow: hidden;
        }

        img {
            width: 100%;
            aspect-ratio: 1/1;
            object-fit: cover;
            transition: transform 0.3s, filter 0.3s;
        }

        .gallery-item:hover img {
            transform: scale(1.1);
            filter: brightness(70%);
        }

        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            opacity: 0;
            transition: opacity 0.3s;
        }

        .gallery-item:hover .overlay {
            opacity: 0.5;
        }

        button {
    position: absolute;
    top: 20px;
    right: 20px;
    padding: 10px 20px;
    background-color: rgb(30, 30, 30);
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s;
}

button:hover {
    background-color: rgb(20, 20, 20);
}

@media (min-width: 768px) {
  /* Adicione seus estilos para telas maiores aqui */
}

/* Estilos para tablets */
@media (max-width: 767px) and (min-width: 576px) {
  /* Adicione seus estilos para tablets aqui */
}

/* Estilos para dispositivos móveis */
@media (max-width: 575px) {
  /* Adicione seus estilos para dispositivos móveis aqui */
}
    </style>

</head>

<body>
    <h1>Galeria de Fotos</h1>
    <button onclick="redirectUser()">Voltar</button>
    Voltar
</button>




    <section class="gallery">
        <div class="gallery-item">
            <img src="https://www.cnnbrasil.com.br/wp-content/uploads/sites/12/2023/09/GettyImages-1668971338-e1694439970587.jpg?w=1220&h=674&crop=1" alt="">
            <div class="overlay"></div>
        </div>
        <div class="gallery-item">
            <img src="https://i.superesportes.com.br/PpxzXETYt55kkBunHCuFofff8Mc=/1200x900/smart/imgsapp.mg.superesportes.com.br/app/noticia_126420360808/2023/01/16/3986015/neymar_1_63882.jpg" alt="">
            <div class="overlay"></div>
        </div>
      
        <div class="gallery-item">
            <img src="https://s2.glbimg.com/DZxFltgy2T9zZRZVtbwL2P_JbuY=/e.glbimg.com/og/ed/f/original/2018/06/19/nariko.jpg" alt="">
            <div class="overlay"></div>
        </div>

        <div class="gallery-item">
            <img src="https://s2-ge.glbimg.com/BDPiCQX0qsmadMcGY9pmnoJqeXY=/0x0:440x481/984x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_bc8228b6673f488aa253bbcb03c80ec5/internal_photos/bs/2022/Z/h/yhho9VRLKIVxAiwCQfaA/neymarrr.jpg" alt="">
            <div class="overlay"></div>
        </div>

        <div class="gallery-item">
            <img src="https://imagens.brasil.elpais.com/resizer/4X-qs0coKYKhMXVSOPQfoSudbBk=/1960x1470/cloudfront-eu-central-1.images.arcpublishing.com/prisa/GOQ56ZN5CPVKYLLURD2LJ6ROT4.jpg" alt="">
            <div class="overlay"></div>
        </div>

        <div class="gallery-item">
            <img src="https://i.pinimg.com/originals/0a/9f/2c/0a9f2c7c49e285365640b9ff0c0bedc0.jpg" alt="">
            <div class="overlay"></div>
        </div>

        
        <div class="gallery-item">
            <img src="https://thumbs.web.sapo.io/?W=800&H=0&delay_optim=1&epic=YWM0QYbErgQC+wOAXZ68PeeYinBOkm8LIkd6hKxF//NN9jyaNU5e+G7ahMCLsZI1KeVGxL2CfHIz3EgsGbUiTbResw2KrFUpByF4zoRwZUB7ztE=" alt="">
            <div class="overlay"></div>
        </div>

        
        <div class="gallery-item">
            <img src="https://blog.newoldman.com.br/wp-content/uploads/2019/03/Cabelos-do-Neymar-Jr.-Todos-os-cortes-ja-usados-pelo-menino-Ney-24.jpg" alt="">
            <div class="overlay"></div>
        </div>

        
        <div class="gallery-item">
            <img src="https://i0.statig.com.br/bancodeimagens/imgalta/eq/9r/0d/eq9r0dhpuw6r1ghyhypwh0ueh.jpg" alt="">
            <div class="overlay"></div>
        </div>

        
        <div class="gallery-item">
            <img src="https://i.pinimg.com/564x/4f/55/89/4f55892df8470426a1d4f0bad495ff06.jpg" alt="">
            <div class="overlay"></div>
        </div>

        
        <div class="gallery-item">
            <img src="https://blog.newoldman.com.br/wp-content/uploads/2019/03/Cabelos-do-Neymar-Jr.-Todos-os-cortes-ja-usados-pelo-menino-Ney-23.jpg" alt="">
            <div class="overlay"></div>
        </div>

        
        <div class="gallery-item">
            <img src="https://medias.itatiaia.com.br/generic/richarlison-lanca-nova-moda-de-corte-de-cabelo-eafbe732-abf0-4ac1-b390-7a318de1422a.jpg" alt="">
            <div class="overlay"></div>
        </div>

        
        <div class="gallery-item">
            <img src="https://m.extra.globo.com/incoming/22787733-294-43d/w640h360-PROP/neymar-cabelo.jpg" alt="">
            <div class="overlay"></div>
        </div>

        
        <div class="gallery-item">
            <img src="https://www.correiodopovo.com.br/image/policy:1.721905:1636647119/FBL-WC-2022-SAMERICA-QUALIFIERS-BRA-TRAIINING.jpg?a=1%3A1&$p$a=b6c30fc" alt="">
            <div class="overlay"></div>
        </div>
        
        <div class="gallery-item">
            <img src="https://images.redetv.uol.com.br/public/esporte/redetviesportes/20200812163430I2VySPVDwP.jpeg" alt="">
            <div class="overlay"></div>
        </div>
       
    </section>
    
    <script>
        function redirectUser() {
            // Verificar se o usuário está em sessão ou não
            var userLoggedIn = '<?php echo isset($_SESSION['email']) ? "true" : "false"; ?>';
            if (userLoggedIn === "true") {
                window.location.href = 'home.php';
            } else {
                window.location.href = 'index.php';
            }
        }
    </script>
</body>

</html>
