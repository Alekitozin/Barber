let menu = document.querySelector("#menu-icon");
let navlist = document.querySelector(".navlist");

menu.onclick = () => {
  menu.classList.toggle("bx-x");
  navlist.classList.toggle("open");
};

const sr = ScrollReveal({
  distance: "65px",
  duration: 2600,
  Delay: 450,
  reset: true,
});

sr.reveal(".logotipo-text", { delay: 200, origin: "top" });
sr.reveal(".logotipo-img", { delay: 450, origin: "top" });
sr.reveal(".icons", { delay: 500, origin: "left" });
sr.reveal(".scroll-down", { delay: 500, origin: "right" });

// Adicione o JavaScript abaixo
function openCalendario() {
  const calendarioContainer = document.querySelector(".container");

  const telaAgendamento = document.createElement("div");
  telaAgendamento.classList.add("tela-agendamento");
  document.body.appendChild(telaAgendamento);

  const iframe = document.createElement("iframe");
  iframe.src = "calendario.php"; // Alterado para o arquivo calendario.php
  iframe.frameBorder = 0;
  iframe.allowFullscreen = true;
  iframe.classList.add("iframe-agendamento");
  document.body.appendChild(iframe);

  const closeButton = document.createElement("button");
  closeButton.textContent = "Fechar";
  closeButton.classList.add("close-button");
  document.body.appendChild(closeButton);

  closeButton.addEventListener("click", function () {
    document.body.removeChild(telaAgendamento);
    document.body.removeChild(iframe);
    document.body.removeChild(closeButton);
  });
}
